﻿#pragma once

// =========================================================================
// 		 ðŸ“¦ DC_Lib API Aggregation Header (api.hpp)
// -------------------------------------------------------------------------
// Provides a unified, single-file interface to access all core components 
// of the DC_Lib custom robotics library.
// =========================================================================

/// @file api.hpp
/// @brief Central include file for the DC_Lib library.

// === Core Utility and Math Components ===

/**
 * @brief Includes general utilities, constants (Wheel_Size), aliases (Aliases),
 * and unit conversion functions.
 * Also defines the DC_Lib::util::units::Percentage type.
 */
#include "DC_Lib/util.hpp" 

// === Hardware Abstraction Layer (HAL) Components ===

/**
 * @brief Includes the DC_Motor class.
 * Provides custom, task-based control (PID, slew, anti-stall) for a single V5 motor.
 */
#include "DC_Lib/Motor.hpp"

/**
 * @brief Includes the DC_MotorGroup class.
 * Provides a unified interface to control a collection of DC_Motor objects.
 */
#include "DC_Lib/Motor_Group.hpp"


// === Advanced Control / Autonomous Components ===

/**
 * @brief Placeholder for an Autonomous Route Calculation system.
 * This is currently commented out, meaning the feature is either disabled, 
 * under development, or not required for the current build.
 */
//#include "DC_Lib/AutoRouteCalc.hpp"


// === Global Scope Imports ===

/**
 * @brief Imports the custom C++ user-defined literal operator `_perc` 
 * (e.g., `50_perc`) into the current scope (global scope after this header is included).
 * This allows user code to write percentages concisely.
 */
using DC_Lib::util::units::percentage_literals::operator"" _perc;
